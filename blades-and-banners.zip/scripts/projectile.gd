extends Area3D
## Geschoss: Pfeil, Dolch, Feuerball oder Lichtkugel.

var direction: Vector3 = Vector3(0, 0, -1)
var speed: float = 22.0
var damage: int = 20
var life: float = 0.7
var radius: float = 0.25
var explode_radius: float = 0.0
var heal_on_hit: int = 0
var color: Color = Color(1.0, 0.85, 0.2)
var owner_player: Node = null

var _done: bool = false


func _ready() -> void:
	collision_layer = 8          # Ebene 4: Geschosse
	collision_mask = 1 | 4       # Welt (1) und Gegner (3)
	var shape := CollisionShape3D.new()
	var sphere := SphereShape3D.new()
	sphere.radius = radius
	shape.shape = sphere
	add_child(shape)

	var mesh := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = radius * 0.8
	sm.height = radius * 1.6
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.emission_enabled = true
	mat.emission = color
	sm.material = mat
	mesh.mesh = sm
	add_child(mesh)

	body_entered.connect(_on_body_entered)


func _physics_process(delta: float) -> void:
	if _done:
		return
	global_position += direction * speed * delta
	life -= delta
	if life <= 0.0:
		_finish(null)


func _on_body_entered(body: Node3D) -> void:
	if _done:
		return
	_finish(body)


func _finish(body: Node3D) -> void:
	_done = true
	if explode_radius > 0.0:
		_explode()
	elif body != null and body.has_method("take_damage"):
		body.call("take_damage", damage)
		if body.is_in_group("enemies"):
			_report_hit()
	queue_free()


func _report_hit() -> void:
	if is_instance_valid(owner_player):
		owner_player.call("on_hit_enemy", damage, true)
		if heal_on_hit > 0:
			owner_player.call("heal", heal_on_hit)


func _explode() -> void:
	for e in get_tree().get_nodes_in_group("enemies"):
		var n := e as Node3D
		if n == null:
			continue
		var flat := Vector2(n.global_position.x - global_position.x, n.global_position.z - global_position.z)
		if flat.length() <= explode_radius:
			n.call("take_damage", damage)
			_report_hit()
	# Kleiner Explosionseffekt
	var fx := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = explode_radius
	sm.height = explode_radius * 2.0
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(color, 0.45)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.material = mat
	fx.mesh = sm
	get_parent().add_child(fx)
	fx.global_position = global_position
	fx.scale = Vector3.ONE * 0.4
	var tw := fx.create_tween()
	tw.set_parallel(true)
	tw.tween_property(fx, "scale", Vector3.ONE, 0.25)
	tw.tween_property(mat, "albedo_color:a", 0.0, 0.25)
	tw.chain().tween_callback(fx.queue_free)
