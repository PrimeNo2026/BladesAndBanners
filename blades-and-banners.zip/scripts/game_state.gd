extends Node
## Autoload "GameState": Spielstand, Trophäen, Banner, Schmiedesteine, Offline-Tageslimit.
## Alle Zahlen sind Beispielwerte und werden beim Balancing festgelegt.

const Champions := preload("res://scripts/champions.gd")

const SAVE_PATH := "user://save.json"
const MILESTONES: Array = [50, 100, 200, 350, 500, 750, 1000, 1500, 2000, 3000]
const WIN_WAVE := 10
const MAX_BONUS_WAVE := 20
const LOSS_TROPHIES := 5
const PROTECTED_BELOW := 100
const OFFLINE_DAILY_LIMIT := 50

var trophies: int = 0
var banners: int = 0
var forge_stones: int = 0
var best_wave: int = 0
var offline_today: int = 0
var day_key: String = ""
var last_seen: int = 0
var claimed_milestones: int = 0
var selected_champion: String = "brannic"
var selected_mode: String = "waves"
var is_offline: bool = true


func _ready() -> void:
	load_game()
	refresh_day()


## Setzt den Tageszähler zurück, sobald ein neuer Tag beginnt.
## Springt die Handy-Uhr zurück, wird NICHT zurückgesetzt (Schutz vor Uhr-Tricks).
func refresh_day() -> void:
	var now := int(Time.get_unix_time_from_system())
	if now < last_seen - 120:
		return
	var today := Time.get_date_string_from_system()
	if today != day_key:
		day_key = today
		offline_today = 0
	last_seen = now
	save_game()


func next_milestone() -> int:
	for m in MILESTONES:
		if int(m) > trophies:
			return int(m)
	return int(MILESTONES.back())


func prev_milestone() -> int:
	var p := 0
	for m in MILESTONES:
		if int(m) <= trophies:
			p = int(m)
	return p


## Wertet einen Durchgang im Wellenüberleben aus und speichert das Ergebnis.
func apply_run_result(wave: int) -> Dictionary:
	refresh_day()
	var res := {
		"wave": wave,
		"won": false,
		"trophy_delta": 0,
		"stones": 0,
		"banners": 0,
		"limit_reached": false,
		"halved": is_offline,
		"new_best": false,
	}
	if wave > best_wave:
		best_wave = wave
		res["new_best"] = true

	if wave >= WIN_WAVE:
		res["won"] = true
		var bonus_wave := mini(wave, MAX_BONUS_WAVE)
		var gain := 8 + 2 * (bonus_wave - WIN_WAVE)
		var stones := 5 + (bonus_wave - WIN_WAVE)
		if is_offline:
			gain = ceili(gain * 0.5)
			stones = ceili(stones * 0.5)
			var left := OFFLINE_DAILY_LIMIT - offline_today
			if left <= 0:
				gain = 0
				stones = 0
				res["limit_reached"] = true
			elif gain > left:
				gain = left
			offline_today += gain
		trophies += gain
		forge_stones += stones
		res["trophy_delta"] = gain
		res["stones"] = stones
	else:
		var before := trophies
		if trophies > PROTECTED_BELOW:
			trophies = maxi(PROTECTED_BELOW, trophies - LOSS_TROPHIES)
		res["trophy_delta"] = trophies - before

	var reached := 0
	for m in MILESTONES:
		if trophies >= int(m):
			reached += 1
	if reached > claimed_milestones:
		res["banners"] = reached - claimed_milestones
		banners += reached - claimed_milestones
		claimed_milestones = reached

	save_game()
	return res


func reset_all() -> void:
	trophies = 0
	banners = 0
	forge_stones = 0
	best_wave = 0
	offline_today = 0
	claimed_milestones = 0
	selected_champion = "brannic"
	save_game()


func save_game() -> void:
	var data := {
		"trophies": trophies,
		"banners": banners,
		"forge_stones": forge_stones,
		"best_wave": best_wave,
		"offline_today": offline_today,
		"day_key": day_key,
		"last_seen": last_seen,
		"claimed_milestones": claimed_milestones,
		"selected_champion": selected_champion,
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(data))
	f.close()


func load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	var d: Dictionary = parsed
	trophies = int(d.get("trophies", 0))
	banners = int(d.get("banners", 0))
	forge_stones = int(d.get("forge_stones", 0))
	best_wave = int(d.get("best_wave", 0))
	offline_today = int(d.get("offline_today", 0))
	day_key = String(d.get("day_key", ""))
	last_seen = int(d.get("last_seen", 0))
	claimed_milestones = int(d.get("claimed_milestones", 0))
	selected_champion = String(d.get("selected_champion", "brannic"))
	if not Champions.DATA.has(selected_champion):
		selected_champion = "brannic"
