extends Node3D
## Spielszene: Arena "Burghof von Hohenwacht" mit Wellenüberleben.
## Handy: links bewegen, rechts ziehen = zielen, loslassen = schießen (kurz tippen = Auto-Ziel).
## PC: WASD bewegen, linke Maustaste schießt zur Maus, Leertaste Auto-Ziel, Q Spezial, E Super.

const Player := preload("res://scripts/player.gd")
const Enemy := preload("res://scripts/enemy.gd")
const Crate := preload("res://scripts/crate.gd")
const GameHud := preload("res://scripts/game_hud.gd")

const ARENA_X := 20.0
const ARENA_Z := 11.5
const CAM_OFFSET := Vector3(0, 16, 10)
const MAX_ALIVE := 14

var player: Player
var camera: Camera3D
var hud: GameHud

var wave: int = 0
var kills: int = 0

var _state: String = "between"
var _timer: float = 2.0
var _to_spawn: int = 0
var _spawn_timer: float = 0.0
var _over: bool = false


func _ready() -> void:
	randomize()
	_build_environment()
	_build_arena()

	player = Player.new()
	player.champion_id = GameState.selected_champion
	add_child(player)
	player.global_position = Vector3(0, 0, 3)

	camera = Camera3D.new()
	camera.fov = 50.0
	camera.rotation = Vector3(-atan2(CAM_OFFSET.y, CAM_OFFSET.z), 0.0, 0.0)
	add_child(camera)
	camera.make_current()
	camera.global_position = player.global_position + CAM_OFFSET

	hud = GameHud.new()
	add_child(hud)
	hud.set_health(player.hp, player.max_hp)
	hud.set_ammo(player.ammo, Player.MAX_AMMO)
	hud.right_stick.stick_released.connect(_on_aim_released)
	hud.special_btn.pressed.connect(func(): player.use_special())
	hud.super_btn.pressed.connect(func(): player.use_super())
	hud.restart_pressed.connect(_on_restart)
	hud.menu_pressed.connect(_on_menu)
	hud.give_up_pressed.connect(_finish_run)
	player.health_changed.connect(hud.set_health)
	player.ammo_changed.connect(hud.set_ammo)
	player.died.connect(_finish_run)


func _process(delta: float) -> void:
	if _over:
		return
	var target := player.global_position + CAM_OFFSET
	camera.global_position = camera.global_position.lerp(target, clampf(delta * 8.0, 0.0, 1.0))

	player.move_input = hud.left_stick.direction
	var rs: Vector2 = hud.right_stick.direction
	if hud.right_stick.active and rs.length() > 0.2:
		player.set_aiming(true, Vector3(rs.x, 0.0, rs.y))
	else:
		player.set_aiming(false)

	hud.special_btn.set_ratio(player.special_ratio())
	hud.super_btn.set_ratio(player.super_ratio())
	_update_waves(delta)


func _on_aim_released(dir: Vector2, dragged: bool) -> void:
	if _over:
		return
	if dragged:
		player.fire(Vector3(dir.x, 0.0, dir.y))
	else:
		player.fire(player.auto_aim_dir())


func _unhandled_input(event: InputEvent) -> void:
	if _over or player.dead:
		return
	if event is InputEventKey:
		var k := event as InputEventKey
		if k.pressed and not k.echo:
			if k.physical_keycode == KEY_Q:
				player.use_special()
			elif k.physical_keycode == KEY_E:
				player.use_super()
			elif k.physical_keycode == KEY_SPACE:
				player.fire(player.auto_aim_dir())
	elif event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		# Vom Touch erzeugte Maus-Events ignorieren, die Sticks übernehmen das
		if mb.pressed and mb.button_index == MOUSE_BUTTON_LEFT and mb.device != InputEvent.DEVICE_ID_EMULATION:
			var from := camera.project_ray_origin(mb.position)
			var ray := camera.project_ray_normal(mb.position)
			var hit: Variant = Plane(Vector3.UP, 0.9).intersects_ray(from, ray)
			if hit != null:
				player.fire((hit as Vector3) - player.global_position)


# ---------------------------------------------------------------- Wellen

func _update_waves(delta: float) -> void:
	if _state == "between":
		_timer -= delta
		if _timer <= 0.0:
			wave += 1
			_to_spawn = 4 + int(wave * 1.5)
			_spawn_timer = 0.0
			_state = "fighting"
			hud.set_wave(wave)
			hud.show_message("Welle %d" % wave, 1.8)
	elif _state == "fighting":
		_spawn_timer -= delta
		var alive := get_tree().get_nodes_in_group("enemies").size()
		if _to_spawn > 0 and _spawn_timer <= 0.0 and alive < MAX_ALIVE:
			_spawn_enemy()
			_to_spawn -= 1
			_spawn_timer = 0.45
		elif _to_spawn == 0 and alive == 0:
			_state = "between"
			_timer = 3.0
			player.heal(int(player.max_hp * 0.15))
			hud.show_message("Welle %d geschafft" % wave, 1.5)


func _spawn_enemy() -> void:
	var side := -1.0 if randi() % 2 == 0 else 1.0
	var pos := Vector3(side * randf_range(15.5, 18.5), 0.0, randf_range(-4.5, 4.5))
	var e := Enemy.new()
	e.target = player
	e.max_hp = 35 + 5 * wave
	e.hp = e.max_hp
	e.speed = minf(2.4 + 0.1 * wave, 4.2)
	e.contact_damage = 6 + int(wave / 3.0)
	add_child(e)
	e.global_position = pos
	e.killed.connect(_on_enemy_killed)


func _on_enemy_killed() -> void:
	kills += 1


# ---------------------------------------------------------------- Ende des Durchgangs

func _finish_run() -> void:
	if _over:
		return
	_over = true
	get_tree().paused = false
	player.set_physics_process(false)
	for e in get_tree().get_nodes_in_group("enemies"):
		e.set_physics_process(false)
	var res := GameState.apply_run_result(wave)
	hud.show_result(_result_text(res))


func _result_text(res: Dictionary) -> String:
	var lines := PackedStringArray()
	lines.append("Welle %d erreicht" % int(res["wave"]))
	if bool(res["won"]):
		lines.append("Sieg!")
	else:
		lines.append("Niederlage (Sieg ab Welle %d)" % GameState.WIN_WAVE)
	var td := int(res["trophy_delta"])
	lines.append("Trophäen: %s%d" % ["+" if td > 0 else "", td])
	if bool(res["won"]):
		lines.append("Schmiedesteine: +%d" % int(res["stones"]))
	if int(res["banners"]) > 0:
		lines.append("Neues Banner: +%d" % int(res["banners"]))
	if bool(res["limit_reached"]):
		lines.append("Tageslimit für Offline-Trophäen erreicht")
	elif bool(res["won"]) and bool(res["halved"]):
		lines.append("Offline: halbe Belohnung")
	if bool(res["new_best"]):
		lines.append("Neuer Rekord!")
	return "\n".join(lines)


func _on_restart() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()


func _on_menu() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/menu.tscn")


# ---------------------------------------------------------------- Arena

func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	return m


func _build_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.45, 0.62, 0.85)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.85, 0.88, 1.0)
	env.ambient_light_energy = 0.7
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -30, 0)
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 45.0
	add_child(sun)


func _add_box(pos: Vector3, size: Vector3, color: Color) -> void:
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	var shape := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	shape.shape = bs
	body.add_child(shape)
	var mesh := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	bm.material = _mat(color)
	mesh.mesh = bm
	body.add_child(mesh)
	add_child(body)
	body.position = pos


func _add_visual_box(pos: Vector3, size: Vector3, color: Color, emissive: bool = false) -> void:
	var mesh := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	var mat := _mat(color)
	if emissive:
		mat.emission_enabled = true
		mat.emission = color
	bm.material = mat
	mesh.mesh = bm
	add_child(mesh)
	mesh.position = pos


func _add_disc(pos: Vector3, radius: float, color: Color) -> void:
	var mesh := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = radius
	cyl.bottom_radius = radius
	cyl.height = 0.04
	var mat := _mat(color)
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	cyl.material = mat
	mesh.mesh = cyl
	add_child(mesh)
	mesh.position = pos


func _build_arena() -> void:
	# Boden
	var floor_mesh := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(ARENA_X * 2.0, ARENA_Z * 2.0)
	plane.material = _mat(Color(0.55, 0.52, 0.47))
	floor_mesh.mesh = plane
	add_child(floor_mesh)

	# Spawn-Zonen (nur optisch)
	for side: float in [-1.0, 1.0]:
		_add_disc(Vector3(side * 17.0, 0.03, 0.0), 4.2, Color(0.3, 0.45, 0.8))

	# Banner-Punkte (im Wellenüberleben nur zur Orientierung)
	for z: float in [-6.5, 0.0, 6.5]:
		_add_disc(Vector3(0.0, 0.03, z), 1.8, Color(0.9, 0.7, 0.2))
		_add_visual_box(Vector3(0.0, 1.4, z), Vector3(0.12, 2.8, 0.12), Color(0.8, 0.8, 0.85))
		_add_visual_box(Vector3(0.65, 2.3, z), Vector3(1.2, 0.7, 0.06), Color(0.95, 0.75, 0.2), true)

	# Außenmauern
	var tx := ARENA_X + 0.5
	var tz := ARENA_Z + 0.5
	var wall_col := Color(0.38, 0.36, 0.34)
	_add_box(Vector3(0, 1.0, -tz), Vector3(ARENA_X * 2.0 + 2.0, 2.0, 1.0), wall_col)
	_add_box(Vector3(0, 1.0, tz), Vector3(ARENA_X * 2.0 + 2.0, 2.0, 1.0), wall_col)
	_add_box(Vector3(-tx, 1.0, 0), Vector3(1.0, 2.0, ARENA_Z * 2.0 + 2.0), wall_col)
	_add_box(Vector3(tx, 1.0, 0), Vector3(1.0, 2.0, ARENA_Z * 2.0 + 2.0), wall_col)

	# Mauern als Deckung (spiegelsymmetrisch)
	for sx: float in [-1.0, 1.0]:
		_add_box(Vector3(sx * 6.8, 1.1, -7.7), Vector3(1.0, 2.2, 4.6), wall_col)
		_add_box(Vector3(sx * 6.8, 1.1, 7.7), Vector3(1.0, 2.2, 4.6), wall_col)
		_add_box(Vector3(sx * 6.2, 1.1, 0.0), Vector3(1.0, 2.2, 4.6), wall_col)

	# Hecken (optisch; Versteck-Funktion folgt später) und zerstörbare Kisten
	for sx: float in [-1.0, 1.0]:
		for sz: float in [-1.0, 1.0]:
			_add_visual_box(Vector3(sx * 11.0, 0.65, sz * 6.7), Vector3(3.3, 1.3, 4.0), Color(0.25, 0.5, 0.25))
			var crate := Crate.new()
			add_child(crate)
			crate.position = Vector3(sx * 12.5, 0.8, sz * 1.8)

	# Banner der fünf Häuser und Fackeln an der hinteren Mauer
	var house_cols: Array = [
		Color(0.35, 0.5, 0.8), Color(0.35, 0.65, 0.3), Color(0.85, 0.35, 0.15),
		Color(0.5, 0.3, 0.7), Color(0.9, 0.75, 0.25),
	]
	for i in 5:
		_add_visual_box(Vector3(-12.0 + i * 6.0, 1.1, -ARENA_Z + 0.1), Vector3(1.6, 1.4, 0.08), house_cols[i])
	for tx2: float in [-9.0, -3.0, 3.0, 9.0]:
		_add_visual_box(Vector3(tx2, 0.9, -ARENA_Z + 0.2), Vector3(0.2, 0.6, 0.2), Color(0.35, 0.22, 0.1))
		_add_visual_box(Vector3(tx2, 1.35, -ARENA_Z + 0.2), Vector3(0.28, 0.28, 0.28), Color(1.0, 0.55, 0.1), true)
