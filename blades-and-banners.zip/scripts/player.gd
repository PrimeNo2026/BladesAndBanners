extends CharacterBody3D
## Spielfigur. Jeder Champion hat Angriff, Spezial (Cooldown) und Super (lädt durch Treffer).

const Champions := preload("res://scripts/champions.gd")
const Projectile := preload("res://scripts/projectile.gd")
const Zone := preload("res://scripts/zone.gd")

signal health_changed(hp: int, max_hp: int)
signal ammo_changed(ammo: int, max_ammo: int)
signal died

const MAX_AMMO := 3
const RELOAD_TIME := 1.3
const FIRE_COOLDOWN := 0.22
const SPECIAL_COOLDOWN := 8.0
const SUPER_MAX := 100.0
const SUPER_PER_HIT := 10.0

var champion_id: String = "brannic"
var data: Dictionary = {}
var max_hp: int = 100
var hp: int = 100
var speed: float = 6.0
var ammo: int = MAX_AMMO
var dead: bool = false
var stealth: bool = false
var move_input: Vector2 = Vector2.ZERO

var _reload: float = 0.0
var _cooldown: float = 0.0
var _special_cd: float = 0.0
var _super: float = 0.0
var _aim_dir: Vector3 = Vector3(0, 0, -1)
var _move_dir: Vector3 = Vector3.ZERO
var _aiming: bool = false
var _dash_t: float = 0.0
var _dash_dir: Vector3 = Vector3.ZERO
var _dash_speed: float = 0.0
var _invuln_t: float = 0.0
var _shield_t: float = 0.0
var _stealth_t: float = 0.0
var _bonus: float = 1.0
var _aim_line: MeshInstance3D
var _body: MeshInstance3D


func _ready() -> void:
	data = Champions.DATA[champion_id]
	max_hp = int(data["hp"])
	hp = max_hp
	speed = float(data["speed"])
	add_to_group("player")
	collision_layer = 2          # Ebene 2: Spieler
	collision_mask = 1 | 4       # Welt und Gegner
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING

	var shape := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.45
	cap.height = 1.8
	shape.shape = cap
	shape.position.y = 0.9
	add_child(shape)
	_build_visual()


# ---------------------------------------------------------------- Aussehen

func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	return m


func _add_box(size: Vector3, pos: Vector3, c: Color) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	bm.material = _mat(c)
	mi.mesh = bm
	mi.position = pos
	add_child(mi)


func _build_visual() -> void:
	var col := Color.html(String(data["color"]))
	_body = MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.45
	cm.height = 1.8
	cm.material = _mat(col)
	_body.mesh = cm
	_body.position.y = 0.9
	add_child(_body)

	# Vorderseite markieren
	_add_box(Vector3(0.22, 0.22, 0.5), Vector3(0, 1.0, -0.5), Color(0.2, 0.2, 0.25))

	match champion_id:
		"brannic":
			_body.scale = Vector3(1.15, 1.0, 1.15)
			_add_box(Vector3(0.9, 1.1, 0.12), Vector3(-0.7, 1.0, -0.2), Color(0.8, 0.8, 0.85))
		"elowen":
			_body.scale = Vector3(0.9, 1.0, 0.9)
			_add_box(Vector3(0.08, 1.5, 0.08), Vector3(0.55, 1.0, -0.3), Color(0.45, 0.3, 0.15))
		"orsin":
			var hat := MeshInstance3D.new()
			var cone := CylinderMesh.new()
			cone.top_radius = 0.0
			cone.bottom_radius = 0.5
			cone.height = 0.8
			cone.material = _mat(Color(0.55, 0.1, 0.1))
			hat.mesh = cone
			hat.position = Vector3(0, 2.15, 0)
			add_child(hat)
		"sable":
			var hood := MeshInstance3D.new()
			var sm := SphereMesh.new()
			sm.radius = 0.5
			sm.height = 1.0
			sm.material = _mat(Color(0.2, 0.12, 0.32))
			hood.mesh = sm
			hood.position = Vector3(0, 1.85, 0)
			add_child(hood)
		"liora":
			var halo := MeshInstance3D.new()
			var tm := TorusMesh.new()
			tm.inner_radius = 0.35
			tm.outer_radius = 0.5
			var hmat := _mat(Color(1.0, 0.85, 0.3))
			hmat.emission_enabled = true
			hmat.emission = Color(1.0, 0.8, 0.2)
			tm.material = hmat
			halo.mesh = tm
			halo.position = Vector3(0, 2.2, 0)
			add_child(halo)

	# Ziellinie (nur sichtbar beim Zielen)
	var aim_len := 3.6 if champion_id == "brannic" else 9.0
	_aim_line = MeshInstance3D.new()
	var lm := BoxMesh.new()
	lm.size = Vector3(0.12, 0.02, aim_len)
	var lmat := StandardMaterial3D.new()
	lmat.albedo_color = Color(1, 0.3, 0.2, 0.35)
	lmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	lmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	lm.material = lmat
	_aim_line.mesh = lm
	_aim_line.position = Vector3(0, 0.05, -(0.8 + aim_len * 0.5))
	_aim_line.visible = false
	add_child(_aim_line)


# ---------------------------------------------------------------- Bewegung

func _key(a: Key, b: Key) -> bool:
	return Input.is_physical_key_pressed(a) or Input.is_physical_key_pressed(b)


func _physics_process(delta: float) -> void:
	if dead:
		return

	_cooldown = maxf(0.0, _cooldown - delta)
	_special_cd = maxf(0.0, _special_cd - delta)
	_invuln_t = maxf(0.0, _invuln_t - delta)
	_shield_t = maxf(0.0, _shield_t - delta)
	if _stealth_t > 0.0:
		_stealth_t -= delta
		if _stealth_t <= 0.0:
			_end_stealth()

	# Munition lädt nach: alle RELOAD_TIME Sekunden +1 Schuss
	if ammo < MAX_AMMO:
		_reload += delta
		if _reload >= RELOAD_TIME:
			_reload = 0.0
			ammo += 1
			ammo_changed.emit(ammo, MAX_AMMO)

	# Eingabe: Tastatur (WASD / Pfeile) oder Touch-Stick
	var input := Vector2.ZERO
	input.x = float(_key(KEY_D, KEY_RIGHT)) - float(_key(KEY_A, KEY_LEFT))
	input.y = float(_key(KEY_S, KEY_DOWN)) - float(_key(KEY_W, KEY_UP))
	if input.length() > 1.0:
		input = input.normalized()
	if move_input.length() > 0.08:
		input = move_input
	var dir := Vector3(input.x, 0.0, input.y)
	_move_dir = dir

	if _dash_t > 0.0:
		_dash_t -= delta
		velocity = _dash_dir * _dash_speed
	else:
		velocity = dir * speed
	move_and_slide()

	if dir.length() > 0.1 and not _aiming and _dash_t <= 0.0:
		_aim_dir = dir.normalized()
	rotation.y = atan2(-_aim_dir.x, -_aim_dir.z)


func set_aiming(on: bool, dir: Vector3 = Vector3.ZERO) -> void:
	_aiming = on
	_aim_line.visible = on and not dead
	if on and dir.length() > 0.01:
		_aim_dir = dir.normalized()


# ---------------------------------------------------------------- Hilfsfunktionen

func _nearest_enemy() -> Node3D:
	var best: Node3D = null
	var best_d := INF
	for e in get_tree().get_nodes_in_group("enemies"):
		var n := e as Node3D
		if n == null:
			continue
		var d := global_position.distance_to(n.global_position)
		if d < best_d:
			best_d = d
			best = n
	return best


func auto_aim_dir() -> Vector3:
	var n := _nearest_enemy()
	if n == null:
		return _aim_dir
	var v := n.global_position - global_position
	v.y = 0.0
	if v.length() < 0.01:
		return _aim_dir
	return v.normalized()


func _spawn_projectile(dir: Vector3, dmg: int, spd: float, life: float, col: Color, explode: float = 0.0, heal_amount: int = 0) -> void:
	var p := Projectile.new()
	p.direction = dir
	p.damage = dmg
	p.speed = spd
	p.life = life
	p.color = col
	p.explode_radius = explode
	p.heal_on_hit = heal_amount
	p.owner_player = self
	get_parent().add_child(p)
	p.global_position = global_position + Vector3(0, 0.9, 0) + dir * 0.9


func _add_zone(z: Node3D, pos: Vector3) -> void:
	get_parent().add_child(z)
	z.global_position = Vector3(pos.x, 0.0, pos.z)


func _spawn_fx(pos: Vector3, size: Vector3, rot_y: float, col: Color, t: float) -> void:
	var m := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	b.material = mat
	m.mesh = b
	get_parent().add_child(m)
	m.global_position = pos
	m.rotation.y = rot_y
	var tw := m.create_tween()
	tw.tween_property(mat, "albedo_color:a", 0.0, t)
	tw.tween_callback(m.queue_free)


func _take_bonus() -> float:
	var m := _bonus
	if m > 1.0:
		_end_stealth()
	return m


func _end_stealth() -> void:
	stealth = false
	_stealth_t = 0.0
	_bonus = 1.0
	_body.transparency = 0.0


# ---------------------------------------------------------------- Angriff

func fire(dir: Vector3) -> void:
	if dead or ammo <= 0 or _cooldown > 0.0 or _dash_t > 0.0:
		return
	dir.y = 0.0
	if dir.length() < 0.01:
		dir = _aim_dir
	dir = dir.normalized()
	_aim_dir = dir
	ammo -= 1
	_cooldown = FIRE_COOLDOWN
	ammo_changed.emit(ammo, MAX_AMMO)
	var mult := _take_bonus()
	match champion_id:
		"brannic":
			_attack_brannic(dir, mult)
		"elowen":
			_attack_elowen(dir, mult)
		"orsin":
			_attack_orsin(dir, mult)
		"sable":
			_attack_sable(dir, mult)
		"liora":
			_attack_liora(dir, mult)


func _attack_brannic(dir: Vector3, mult: float) -> void:
	var rot := atan2(-dir.x, -dir.z)
	_spawn_fx(global_position + Vector3(0, 0.9, 0) + dir * 1.6, Vector3(3.2, 0.1, 0.5), rot, Color(0.9, 0.9, 1.0, 0.7), 0.2)
	for e in get_tree().get_nodes_in_group("enemies"):
		var n := e as Node3D
		if n == null:
			continue
		var to := n.global_position - global_position
		to.y = 0.0
		var d := to.length()
		if d <= 3.3 and (d < 0.6 or to.normalized().dot(dir) >= 0.5):
			n.call("take_damage", int(34 * mult))
			on_hit_enemy(34, true)


func _attack_elowen(dir: Vector3, mult: float) -> void:
	for i in 3:
		if dead or not is_inside_tree():
			return
		_spawn_projectile(dir, int(13 * mult), 26.0, 0.75, Color(0.7, 0.9, 0.4))
		if i < 2:
			await get_tree().create_timer(0.09).timeout


func _attack_orsin(dir: Vector3, mult: float) -> void:
	_spawn_projectile(dir, int(24 * mult), 15.0, 0.9, Color(1.0, 0.5, 0.1), 2.3)


func _attack_sable(dir: Vector3, mult: float) -> void:
	_spawn_projectile(dir.rotated(Vector3.UP, deg_to_rad(4.0)), int(14 * mult), 28.0, 0.35, Color(0.75, 0.7, 0.9))
	_spawn_projectile(dir.rotated(Vector3.UP, deg_to_rad(-4.0)), int(14 * mult), 28.0, 0.35, Color(0.75, 0.7, 0.9))


func _attack_liora(dir: Vector3, mult: float) -> void:
	_spawn_projectile(dir, int(16 * mult), 20.0, 0.7, Color(1.0, 0.95, 0.6), 0.0, 3)


# ---------------------------------------------------------------- Spezial

func use_special() -> void:
	if dead or _special_cd > 0.0 or _dash_t > 0.0:
		return
	var d := _aim_dir
	d.y = 0.0
	if d.length() < 0.01:
		d = Vector3(0, 0, -1)
	d = d.normalized()
	var ok := false
	match champion_id:
		"brannic":
			ok = _special_brannic(d)
		"elowen":
			ok = _special_elowen(d)
		"orsin":
			ok = _special_orsin(d)
		"sable":
			ok = _special_sable(d)
		"liora":
			ok = _special_liora()
	if ok:
		_special_cd = SPECIAL_COOLDOWN


func _special_brannic(d: Vector3) -> bool:
	_dash_dir = d
	_dash_speed = 14.0
	_dash_t = 0.25
	for e in get_tree().get_nodes_in_group("enemies"):
		var n := e as Node3D
		if n == null:
			continue
		var rel := n.global_position - global_position
		rel.y = 0.0
		var along := rel.dot(d)
		var across := (rel - d * along).length()
		if along > -0.5 and along < 4.5 and across < 1.5:
			n.call("take_damage", 12)
			n.call("knockback", d, 3.0)
			on_hit_enemy(12, true)
	_spawn_fx(global_position + Vector3(0, 0.9, 0) + d * 1.5, Vector3(2.4, 0.1, 1.2), atan2(-d.x, -d.z), Color(0.5, 0.7, 1.0, 0.7), 0.25)
	return true


func _special_elowen(d: Vector3) -> bool:
	var r := _move_dir
	if r.length() < 0.1:
		r = -d
	_dash_dir = r.normalized()
	_dash_speed = 15.0
	_dash_t = 0.28
	_invuln_t = 0.4
	return true


func _special_orsin(d: Vector3) -> bool:
	var z := Zone.new()
	z.player = self
	z.kind = "damage"
	z.shape = "line"
	z.dir = Vector3(-d.z, 0.0, d.x).normalized()
	z.half_len = 2.6
	z.radius = 0.7
	z.duration = 3.5
	z.tick = 0.4
	z.amount = 8
	z.color = Color(1.0, 0.45, 0.1)
	_add_zone(z, global_position + d * 4.0)
	return true


func _special_sable(d: Vector3) -> bool:
	var from := global_position
	var dist := 6.0
	while dist > 0.5 and test_move(global_transform, d * dist):
		dist -= 0.5
	if dist <= 0.5:
		return false
	global_position += d * dist
	_spawn_fx(from + Vector3(0, 0.9, 0), Vector3(1.0, 1.8, 1.0), 0.0, Color(0.4, 0.2, 0.6, 0.6), 0.4)
	_spawn_fx(global_position + Vector3(0, 0.9, 0), Vector3(1.0, 1.8, 1.0), 0.0, Color(0.4, 0.2, 0.6, 0.6), 0.4)
	return true


func _special_liora() -> bool:
	var z := Zone.new()
	z.player = self
	z.kind = "heal"
	z.shape = "circle"
	z.radius = 3.5
	z.duration = 4.0
	z.tick = 0.5
	z.amount = 8
	z.color = Color(0.5, 1.0, 0.6)
	_add_zone(z, global_position)
	return true


# ---------------------------------------------------------------- Super

func use_super() -> void:
	if dead or _super < SUPER_MAX:
		return
	_super = 0.0
	var d := _aim_dir
	d.y = 0.0
	if d.length() < 0.01:
		d = Vector3(0, 0, -1)
	d = d.normalized()
	match champion_id:
		"brannic":
			_super_brannic()
		"elowen":
			_super_elowen(d)
		"orsin":
			_super_orsin(d)
		"sable":
			_super_sable()
		"liora":
			_super_liora()


func _super_brannic() -> void:
	var z := Zone.new()
	z.player = self
	z.kind = "guard"
	z.shape = "circle"
	z.radius = 5.0
	z.duration = 8.0
	z.color = Color(0.3, 0.5, 1.0)
	_add_zone(z, global_position)


func _super_elowen(d: Vector3) -> void:
	var target := global_position + d * 7.0
	var n := _nearest_enemy()
	if n != null and global_position.distance_to(n.global_position) <= 13.0:
		target = n.global_position
	var z := Zone.new()
	z.player = self
	z.kind = "damage"
	z.shape = "circle"
	z.radius = 4.0
	z.duration = 3.0
	z.tick = 0.5
	z.amount = 9
	z.slow = 0.5
	z.color = Color(0.4, 0.8, 0.3)
	_add_zone(z, target)


func _super_orsin(d: Vector3) -> void:
	var z := Zone.new()
	z.player = self
	z.kind = "damage"
	z.shape = "circle"
	z.radius = 5.0
	z.duration = 4.0
	z.tick = 0.5
	z.amount = 14
	z.color = Color(0.9, 0.3, 0.05)
	_add_zone(z, global_position + d * 6.0)


func _super_sable() -> void:
	stealth = true
	_stealth_t = 4.0
	_bonus = 2.0
	_body.transparency = 0.65


func _super_liora() -> void:
	heal(int(max_hp * 0.5))
	_shield_t = 2.0
	_spawn_fx(global_position + Vector3(0, 0.1, 0), Vector3(7.0, 0.05, 7.0), 0.0, Color(1.0, 0.9, 0.4, 0.6), 0.6)


# ---------------------------------------------------------------- Treffer, Leben

func on_hit_enemy(_dmg: int = 0, charge: bool = true) -> void:
	if charge:
		_super = minf(SUPER_MAX, _super + SUPER_PER_HIT)


func special_ratio() -> float:
	return 1.0 - _special_cd / SPECIAL_COOLDOWN


func super_ratio() -> float:
	return _super / SUPER_MAX


func heal(amount: int) -> void:
	if dead:
		return
	hp = mini(max_hp, hp + amount)
	health_changed.emit(hp, max_hp)


func take_damage(amount: int) -> void:
	if dead or _invuln_t > 0.0 or _shield_t > 0.0:
		return
	var m := 1.0
	for z in get_tree().get_nodes_in_group("guard_zones"):
		if bool(z.call("contains", global_position)):
			m = 0.5
	var dmg := maxi(1, int(round(amount * m)))
	hp = maxi(0, hp - dmg)
	health_changed.emit(hp, max_hp)
	var pulse := _body.scale * 1.15
	var base := _body.scale
	_body.scale = pulse
	create_tween().tween_property(_body, "scale", base, 0.15)
	if hp == 0:
		dead = true
		velocity = Vector3.ZERO
		_aim_line.visible = false
		_body.visible = false
		died.emit()
