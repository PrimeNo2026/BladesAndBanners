extends Control
## Schwebender virtueller Touch-Stick. Erscheint dort, wo der Finger die Zone berührt.

signal stick_released(direction: Vector2, dragged: bool)

@export var max_distance: float = 90.0
@export var drag_threshold: float = 0.3
@export var tint: Color = Color(1, 1, 1)

## Controls (z. B. Fähigkeiten-Knöpfe), auf denen kein Stick starten darf.
var blockers: Array = []
var direction: Vector2 = Vector2.ZERO
var active: bool = false

var _index: int = -1
var _origin: Vector2 = Vector2.ZERO
var _knob: Vector2 = Vector2.ZERO


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _to_local_pos(p: Vector2) -> Vector2:
	return get_global_transform().affine_inverse() * p


func _is_blocked(p: Vector2) -> bool:
	for b in blockers:
		var c := b as Control
		if c != null and is_instance_valid(c) and c.get_global_rect().has_point(p):
			return true
	return false


func _input(event: InputEvent) -> void:
	if not is_visible_in_tree():
		return
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed:
			if _index == -1 and get_global_rect().has_point(t.position) and not _is_blocked(t.position):
				_index = t.index
				active = true
				_origin = _to_local_pos(t.position)
				_knob = _origin
				direction = Vector2.ZERO
				queue_redraw()
		elif t.index == _index:
			var d := direction
			var dragged := d.length() >= drag_threshold
			_index = -1
			active = false
			direction = Vector2.ZERO
			queue_redraw()
			stick_released.emit(d, dragged)
	elif event is InputEventScreenDrag:
		var drag := event as InputEventScreenDrag
		if drag.index == _index:
			var offset := _to_local_pos(drag.position) - _origin
			if offset.length() > max_distance:
				offset = offset.normalized() * max_distance
			_knob = _origin + offset
			direction = offset / max_distance
			queue_redraw()


func _draw() -> void:
	if active:
		draw_circle(_origin, max_distance, Color(tint, 0.15))
		draw_arc(_origin, max_distance, 0.0, TAU, 48, Color(tint, 0.6), 3.0)
		draw_circle(_knob, 38.0, Color(tint, 0.6))
	else:
		var rest := Vector2(size.x * 0.5, size.y * 0.6)
		draw_arc(rest, max_distance, 0.0, TAU, 48, Color(tint, 0.25), 3.0)
