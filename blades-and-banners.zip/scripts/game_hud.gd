extends CanvasLayer
## Anzeige im Spiel: Sticks, Fähigkeiten-Knöpfe, Leben, Munition, Welle, Pause, Ergebnis.

const Joystick := preload("res://scripts/joystick.gd")
const AbilityButton := preload("res://scripts/ability_button.gd")

signal give_up_pressed
signal restart_pressed
signal menu_pressed

var left_stick: Joystick
var right_stick: Joystick
var special_btn: AbilityButton
var super_btn: AbilityButton

var _hp_bar: ProgressBar
var _ammo_label: Label
var _wave_label: Label
var _msg_label: Label
var _msg_tween: Tween
var _pause_panel: Control
var _over_panel: Control
var _over_label: Label


func _ready() -> void:
	special_btn = _make_ability("Spezial", Color(0.4, 0.8, 1.0), 40.0, 40.0)
	super_btn = _make_ability("Super", Color(1.0, 0.8, 0.2), 40.0, 170.0)

	left_stick = Joystick.new()
	left_stick.tint = Color(1, 1, 1)
	_place(left_stick, 0.0, 0.5)
	right_stick = Joystick.new()
	right_stick.tint = Color(1.0, 0.45, 0.35)
	right_stick.blockers = [special_btn, super_btn]
	_place(right_stick, 0.5, 1.0)

	# Obere Leiste
	var margin := MarginContainer.new()
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(margin)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margin.add_theme_constant_override(side, 24)

	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(row)

	var left_box := VBoxContainer.new()
	left_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	left_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(left_box)

	_hp_bar = ProgressBar.new()
	_hp_bar.custom_minimum_size = Vector2(300, 30)
	_hp_bar.max_value = 100
	_hp_bar.value = 100
	_hp_bar.show_percentage = false
	_hp_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	left_box.add_child(_hp_bar)

	_ammo_label = _make_label("Munition 3/3", 26)
	left_box.add_child(_ammo_label)

	_wave_label = _make_label("Bereit", 34)
	_wave_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	row.add_child(_wave_label)

	var right_box := HBoxContainer.new()
	right_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	right_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right_box.alignment = BoxContainer.ALIGNMENT_END
	row.add_child(right_box)

	var pause := Button.new()
	pause.text = "II"
	pause.custom_minimum_size = Vector2(80, 70)
	pause.add_theme_font_size_override("font_size", 30)
	pause.pressed.connect(_on_pause)
	right_box.add_child(pause)

	# Nachricht in der Bildmitte (z. B. "Welle 3")
	var msg_center := CenterContainer.new()
	msg_center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(msg_center)
	msg_center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_msg_label = _make_label("", 64)
	_msg_label.modulate.a = 0.0
	msg_center.add_child(_msg_label)

	_pause_panel = _make_overlay()
	_pause_panel.process_mode = Node.PROCESS_MODE_ALWAYS
	var pbox := _overlay_box(_pause_panel)
	pbox.add_child(_make_label("Pause", 56))
	pbox.add_child(_make_button("Weiter", _on_resume))
	pbox.add_child(_make_button("Aufgeben", _on_give_up))

	_over_panel = _make_overlay()
	var obox := _overlay_box(_over_panel)
	_over_label = _make_label("", 40)
	_over_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	obox.add_child(_over_label)
	obox.add_child(_make_button("Nochmal", func(): restart_pressed.emit()))
	obox.add_child(_make_button("Menü", func(): menu_pressed.emit()))


func _make_ability(label: String, tint: Color, right: float, bottom: float) -> AbilityButton:
	var b := AbilityButton.new()
	b.label_text = label
	b.tint = tint
	add_child(b)
	b.anchor_left = 1.0
	b.anchor_right = 1.0
	b.anchor_top = 1.0
	b.anchor_bottom = 1.0
	b.offset_left = -right - 110.0
	b.offset_right = -right
	b.offset_top = -bottom - 110.0
	b.offset_bottom = -bottom
	return b


func _place(c: Control, from_x: float, to_x: float) -> void:
	add_child(c)
	c.anchor_left = from_x
	c.anchor_right = to_x
	c.anchor_top = 0.3
	c.anchor_bottom = 1.0
	c.offset_left = 0.0
	c.offset_right = 0.0
	c.offset_top = 0.0
	c.offset_bottom = 0.0


func _make_label(text: String, font_size: int) -> Label:
	var l := Label.new()
	l.text = text
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", Color.WHITE)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 6)
	return l


func _make_button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(320, 90)
	b.add_theme_font_size_override("font_size", 36)
	b.pressed.connect(cb)
	return b


func _make_overlay() -> Control:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.65)
	dim.visible = false
	add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	return dim


func _overlay_box(parent: Control) -> VBoxContainer:
	var center := CenterContainer.new()
	parent.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 20)
	center.add_child(box)
	return box


# ---------------------------------------------------------------- Öffentliche Funktionen

func set_health(hp: int, max_hp: int) -> void:
	_hp_bar.max_value = max_hp
	_hp_bar.value = hp


func set_ammo(ammo: int, max_ammo: int) -> void:
	_ammo_label.text = "Munition %d/%d" % [ammo, max_ammo]


func set_wave(n: int) -> void:
	_wave_label.text = "Welle %d" % n


func show_message(text: String, seconds: float) -> void:
	_msg_label.text = text
	if _msg_tween != null:
		_msg_tween.kill()
	_msg_label.modulate.a = 1.0
	_msg_tween = create_tween()
	_msg_tween.tween_interval(seconds)
	_msg_tween.tween_property(_msg_label, "modulate:a", 0.0, 0.4)


func show_result(text: String) -> void:
	_over_label.text = text
	_over_panel.visible = true


func _on_pause() -> void:
	get_tree().paused = true
	_pause_panel.visible = true


func _on_resume() -> void:
	_pause_panel.visible = false
	get_tree().paused = false


func _on_give_up() -> void:
	_pause_panel.visible = false
	get_tree().paused = false
	give_up_pressed.emit()
