extends StaticBody3D
## Zerstörbare Kiste als Deckung.

var hp: int = 60


func _ready() -> void:
	collision_layer = 1
	collision_mask = 0
	var shape := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(1.6, 1.6, 1.6)
	shape.shape = bs
	add_child(shape)

	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(1.6, 1.6, 1.6)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.6, 0.42, 0.22)
	bm.material = mat
	mi.mesh = bm
	add_child(mi)


func take_damage(amount: int) -> void:
	hp -= amount
	if hp <= 0:
		queue_free()
