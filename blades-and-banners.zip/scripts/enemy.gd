extends CharacterBody3D
## Gegner im Wellenüberleben: läuft auf den Spieler zu und greift im Nahkampf an.

signal killed

var target: Node3D
var max_hp: int = 40
var hp: int = 40
var speed: float = 3.0
var contact_damage: int = 8

var _attack_cd: float = 0.0
var _dead: bool = false
var _mesh: MeshInstance3D
var _bar: MeshInstance3D
var _slow_factor: float = 0.0
var _slow_time: float = 0.0
var _kb_vel: Vector3 = Vector3.ZERO
var _kb_time: float = 0.0


func _ready() -> void:
	add_to_group("enemies")
	collision_layer = 4          # Ebene 3: Gegner
	collision_mask = 1 | 2 | 4   # Welt, Spieler, andere Gegner
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING

	var shape := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.5
	cap.height = 1.6
	shape.shape = cap
	shape.position.y = 0.8
	add_child(shape)

	_mesh = MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.5
	cm.height = 1.6
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.55, 0.2, 0.22)
	cm.material = mat
	_mesh.mesh = cm
	_mesh.position.y = 0.8
	add_child(_mesh)

	_bar = MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(1.0, 0.1, 0.1)
	var bmat := StandardMaterial3D.new()
	bmat.albedo_color = Color(0.9, 0.15, 0.15)
	bmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bm.material = bmat
	_bar.mesh = bm
	_bar.position = Vector3(0, 2.0, 0)
	add_child(_bar)


func _physics_process(delta: float) -> void:
	if _dead:
		return
	if _slow_time > 0.0:
		_slow_time -= delta
		if _slow_time <= 0.0:
			_slow_factor = 0.0
	if _kb_time > 0.0:
		_kb_time -= delta
		velocity = _kb_vel
		move_and_slide()
		return
	if target == null or not is_instance_valid(target):
		return

	var to := target.global_position - global_position
	to.y = 0.0
	var dist := to.length()
	var s: Variant = target.get("stealth")
	var stealthed: bool = s == true

	if stealthed:
		velocity = Vector3.ZERO
	elif dist > 1.2:
		velocity = to.normalized() * speed * (1.0 - _slow_factor)
	else:
		velocity = Vector3.ZERO
	move_and_slide()

	_attack_cd -= delta
	if not stealthed and dist < 1.7 and _attack_cd <= 0.0:
		_attack_cd = 0.8
		target.call("take_damage", contact_damage)


func take_damage(amount: int) -> void:
	if _dead:
		return
	hp -= amount
	_bar.scale.x = clampf(float(hp) / float(max_hp), 0.01, 1.0)
	_mesh.scale = Vector3.ONE * 1.2
	create_tween().tween_property(_mesh, "scale", Vector3.ONE, 0.1)
	if hp <= 0:
		_dead = true
		killed.emit()
		queue_free()


func apply_slow(factor: float, duration: float) -> void:
	_slow_factor = clampf(factor, 0.0, 0.9)
	_slow_time = duration


func knockback(dir: Vector3, dist: float) -> void:
	dir.y = 0.0
	if dir.length() < 0.01:
		return
	_kb_vel = dir.normalized() * (dist / 0.2)
	_kb_time = 0.2
