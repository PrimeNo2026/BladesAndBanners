extends Control
## Hauptmenü (Querformat), Aufbau nach der Skizze:
## oben Trophäenpfad, Offline-Zähler, Offline/Online-Anzeige, Einstellungen;
## links Shop, Quests, Champions; Mitte der Champion; rechts Modusliste und PLAY.

const Champions := preload("res://scripts/champions.gd")

const MODES: Array = [
	{"id": "waves", "name": "Wellenüberleben", "ready": true},
	{"id": "banner", "name": "Banner-Eroberung", "ready": false},
	{"id": "crown", "name": "Kronenjagd", "ready": false},
	{"id": "last", "name": "Letzter Held", "ready": false},
]

var _trophy_label: Label
var _trophy_bar: ProgressBar
var _offline_label: Label
var _res_label: Label
var _portrait: Control
var _name_label: Label
var _role_label: Label
var _champ_overlay: Control
var _champ_detail: Label
var _preview_id: String = ""
var _settings_overlay: Control


func _ready() -> void:
	GameState.refresh_day()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var bg := ColorRect.new()
	bg.color = Color(0.09, 0.11, 0.17)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var margin := MarginContainer.new()
	add_child(margin)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margin.add_theme_constant_override(side, 24)

	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 16)
	margin.add_child(root)

	root.add_child(_build_top_bar())

	var middle := HBoxContainer.new()
	middle.size_flags_vertical = Control.SIZE_EXPAND_FILL
	middle.add_theme_constant_override("separation", 20)
	root.add_child(middle)
	middle.add_child(_build_left_column())
	middle.add_child(_build_center())
	middle.add_child(_build_right_column())

	_build_champion_overlay()
	_build_settings_overlay()
	_refresh()


# ---------------------------------------------------------------- Hilfen für das Aussehen

func _box(bg: Color, border: Color, border_w: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(border_w)
	s.set_corner_radius_all(14)
	s.set_content_margin_all(12)
	return s


func _panel() -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", _box(Color(0.16, 0.19, 0.28), Color(0, 0, 0, 0), 0))
	return p


func _label(text: String, font_size: int) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", Color.WHITE)
	return l


func _button(text: String, font_size: int) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_size_override("font_size", font_size)
	var none := Color(0, 0, 0, 0)
	b.add_theme_stylebox_override("normal", _box(Color(0.22, 0.27, 0.4), none, 0))
	b.add_theme_stylebox_override("hover", _box(Color(0.28, 0.34, 0.5), none, 0))
	b.add_theme_stylebox_override("pressed", _box(Color(0.16, 0.2, 0.3), none, 0))
	b.add_theme_stylebox_override("disabled", _box(Color(0.15, 0.17, 0.23), none, 0))
	return b


func _style_all_states(b: Button, sb: StyleBoxFlat) -> void:
	b.add_theme_stylebox_override("normal", sb)
	b.add_theme_stylebox_override("hover", sb)
	b.add_theme_stylebox_override("pressed", sb)


# ---------------------------------------------------------------- Aufbau

func _build_top_bar() -> Control:
	var bar := HBoxContainer.new()
	bar.add_theme_constant_override("separation", 12)
	bar.custom_minimum_size = Vector2(0, 72)

	var p1 := _panel()
	var v1 := VBoxContainer.new()
	p1.add_child(v1)
	_trophy_label = _label("", 22)
	v1.add_child(_trophy_label)
	_trophy_bar = ProgressBar.new()
	_trophy_bar.custom_minimum_size = Vector2(260, 14)
	_trophy_bar.show_percentage = false
	v1.add_child(_trophy_bar)
	bar.add_child(p1)

	var p2 := _panel()
	_offline_label = _label("", 22)
	p2.add_child(_offline_label)
	bar.add_child(p2)

	var p3 := _panel()
	_res_label = _label("", 22)
	p3.add_child(_res_label)
	bar.add_child(p3)

	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bar.add_child(spacer)

	var sw := _button("Offline-Modus (Online bald)", 22)
	sw.disabled = true
	sw.custom_minimum_size = Vector2(330, 72)
	bar.add_child(sw)

	var st := _button("Einstellungen", 22)
	st.custom_minimum_size = Vector2(200, 72)
	st.pressed.connect(func(): _settings_overlay.visible = true)
	bar.add_child(st)
	return bar


func _build_left_column() -> Control:
	var col := VBoxContainer.new()
	col.custom_minimum_size = Vector2(230, 0)
	col.add_theme_constant_override("separation", 14)

	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(spacer)

	var shop := _button("Shop (bald)", 26)
	shop.disabled = true
	shop.custom_minimum_size = Vector2(0, 90)
	col.add_child(shop)

	var quests := _button("Quests (bald)", 26)
	quests.disabled = true
	quests.custom_minimum_size = Vector2(0, 90)
	col.add_child(quests)

	var champs := _button("Champions", 26)
	champs.custom_minimum_size = Vector2(0, 100)
	champs.pressed.connect(_open_champions)
	col.add_child(champs)
	return col


func _build_center() -> Control:
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL

	_portrait = Control.new()
	_portrait.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_portrait.custom_minimum_size = Vector2(300, 300)
	_portrait.draw.connect(_on_portrait_draw)
	col.add_child(_portrait)

	_name_label = _label("", 40)
	_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(_name_label)

	_role_label = _label("", 24)
	_role_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(_role_label)
	return col


func _build_right_column() -> Control:
	var col := VBoxContainer.new()
	col.custom_minimum_size = Vector2(380, 0)
	col.add_theme_constant_override("separation", 14)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	col.add_child(scroll)

	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 10)
	scroll.add_child(list)

	for m in MODES:
		var d: Dictionary = m
		var b := _button(String(d["name"]), 28)
		b.custom_minimum_size = Vector2(0, 84)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		if bool(d["ready"]):
			# Gewählter Modus: rot umrandet
			_style_all_states(b, _box(Color(0.2, 0.24, 0.36), Color(0.9, 0.2, 0.2), 4))
		else:
			b.text = "%s (bald)" % String(d["name"])
			b.disabled = true
		list.add_child(b)

	var play := _button("PLAY", 56)
	play.custom_minimum_size = Vector2(0, 130)
	_style_all_states(play, _box(Color(0.85, 0.55, 0.1), Color(1.0, 0.8, 0.3), 3))
	play.pressed.connect(_on_play)
	col.add_child(play)
	return col


func _build_champion_overlay() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.75)
	dim.visible = false
	add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_champ_overlay = dim

	var center := CenterContainer.new()
	dim.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel := _panel()
	center.add_child(panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	panel.add_child(box)
	box.add_child(_label("Champions", 36))

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	box.add_child(row)
	for id in Champions.ORDER:
		var data: Dictionary = Champions.DATA[id]
		var b := _button("%s\n%s" % [data["name"], data["role"]], 24)
		b.custom_minimum_size = Vector2(190, 100)
		b.pressed.connect(_preview.bind(String(id)))
		row.add_child(b)

	_champ_detail = _label("", 22)
	_champ_detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_champ_detail.custom_minimum_size = Vector2(980, 260)
	box.add_child(_champ_detail)

	var btns := HBoxContainer.new()
	btns.add_theme_constant_override("separation", 14)
	box.add_child(btns)
	var pick := _button("Auswählen", 28)
	pick.custom_minimum_size = Vector2(260, 80)
	pick.pressed.connect(_pick_champion)
	btns.add_child(pick)
	var back := _button("Zurück", 28)
	back.custom_minimum_size = Vector2(200, 80)
	back.pressed.connect(func(): _champ_overlay.visible = false)
	btns.add_child(back)


func _build_settings_overlay() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.75)
	dim.visible = false
	add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_settings_overlay = dim

	var center := CenterContainer.new()
	dim.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel := _panel()
	center.add_child(panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 16)
	panel.add_child(box)
	box.add_child(_label("Einstellungen", 36))
	box.add_child(_label("Blades & Banners · Prototyp 0.2 (nur Offline)", 22))

	var reset := _button("Spielstand zurücksetzen", 26)
	reset.custom_minimum_size = Vector2(480, 80)
	reset.pressed.connect(_on_reset)
	box.add_child(reset)

	var close := _button("Schließen", 26)
	close.custom_minimum_size = Vector2(480, 80)
	close.pressed.connect(func(): _settings_overlay.visible = false)
	box.add_child(close)


# ---------------------------------------------------------------- Aktionen

func _open_champions() -> void:
	_preview(GameState.selected_champion)
	_champ_overlay.visible = true


func _preview(id: String) -> void:
	_preview_id = id
	var d: Dictionary = Champions.DATA[id]
	_champ_detail.text = "%s, %s (%s)\nRolle: %s · Leben %d · Tempo %.1f\nAngriff: %s\nSpezial: %s\nSuper: %s\n%s" % [
		d["name"], d["title"], d["house"], d["role"], int(d["hp"]), float(d["speed"]),
		d["attack"], d["special"], d["super"], d["story"],
	]


func _pick_champion() -> void:
	if _preview_id != "":
		GameState.selected_champion = _preview_id
		GameState.save_game()
	_champ_overlay.visible = false
	_refresh()


func _on_reset() -> void:
	GameState.reset_all()
	_refresh()


func _on_play() -> void:
	GameState.selected_mode = "waves"
	get_tree().change_scene_to_file("res://scenes/game.tscn")


func _refresh() -> void:
	var t := GameState.trophies
	var prev := GameState.prev_milestone()
	var nxt := GameState.next_milestone()
	_trophy_label.text = "Trophäenpfad %d/%d" % [t, nxt]
	_trophy_bar.min_value = prev
	_trophy_bar.max_value = maxi(nxt, prev + 1)
	_trophy_bar.value = t
	_offline_label.text = "Offline heute %d/%d" % [GameState.offline_today, GameState.OFFLINE_DAILY_LIMIT]
	_res_label.text = "Banner %d   Schmiedesteine %d" % [GameState.banners, GameState.forge_stones]
	var d: Dictionary = Champions.DATA[GameState.selected_champion]
	_name_label.text = "%s, %s" % [d["name"], d["title"]]
	_role_label.text = "%s · %s" % [d["role"], d["house"]]
	_portrait.queue_redraw()


func _on_portrait_draw() -> void:
	var id := GameState.selected_champion
	var d: Dictionary = Champions.DATA[id]
	var col := Color.html(String(d["color"]))
	var s := _portrait.size
	var u := minf(s.y, 420.0) / 10.0
	var cx := s.x * 0.5
	var cy := s.y * 0.5

	var body := StyleBoxFlat.new()
	body.bg_color = col
	body.set_corner_radius_all(int(u * 2.0))
	_portrait.draw_style_box(body, Rect2(cx - u * 2.0, cy - u * 3.0, u * 4.0, u * 6.0))
	_portrait.draw_circle(Vector2(cx, cy - u * 4.2), u * 1.5, Color(0.95, 0.8, 0.65))

	if id == "brannic":
		_portrait.draw_rect(Rect2(cx - u * 3.6, cy - u * 1.8, u * 1.6, u * 3.0), Color(0.75, 0.75, 0.8))
	elif id == "elowen":
		_portrait.draw_arc(Vector2(cx + u * 3.0, cy), u * 2.4, -PI * 0.45, PI * 0.45, 24, Color(0.5, 0.33, 0.15), 6.0)
	elif id == "orsin":
		var hat := PackedVector2Array([
			Vector2(cx - u * 1.6, cy - u * 4.9),
			Vector2(cx + u * 1.6, cy - u * 4.9),
			Vector2(cx, cy - u * 8.0),
		])
		_portrait.draw_colored_polygon(hat, Color(0.55, 0.1, 0.1))
	elif id == "sable":
		_portrait.draw_arc(Vector2(cx, cy - u * 4.2), u * 1.7, PI, TAU, 24, Color(0.25, 0.15, 0.4), 8.0)
	elif id == "liora":
		_portrait.draw_arc(Vector2(cx, cy - u * 6.2), u * 1.3, 0.0, TAU, 32, Color(1.0, 0.85, 0.3), 5.0)
