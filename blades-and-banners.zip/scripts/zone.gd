extends Node3D
## Bodenfläche mit Wirkung: Schaden, Heilung oder Schutz (Banner).

var kind: String = "damage"      # "damage", "heal" oder "guard"
var shape: String = "circle"     # "circle" oder "line"
var radius: float = 3.0          # Radius (Kreis) oder halbe Dicke (Linie)
var half_len: float = 2.5        # halbe Länge (nur Linie)
var dir: Vector3 = Vector3(0, 0, -1)
var duration: float = 3.0
var tick: float = 0.5
var amount: int = 5
var slow: float = 0.0
var color: Color = Color(1.0, 0.5, 0.1)
var player: Node3D = null

var _t: float = 0.0
var _tick_t: float = 0.0


func _ready() -> void:
	_tick_t = tick
	if kind == "guard":
		add_to_group("guard_zones")

	var mi := MeshInstance3D.new()
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(color, 0.35)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	if shape == "circle":
		var cyl := CylinderMesh.new()
		cyl.top_radius = radius
		cyl.bottom_radius = radius
		cyl.height = 0.05
		cyl.material = mat
		mi.mesh = cyl
	else:
		var bx := BoxMesh.new()
		bx.size = Vector3(radius * 2.0, 0.05, half_len * 2.0)
		bx.material = mat
		mi.mesh = bx
		mi.rotation.y = atan2(-dir.x, -dir.z)
	mi.position.y = 0.05
	add_child(mi)

	if kind == "guard":
		var pole := MeshInstance3D.new()
		var pm := CylinderMesh.new()
		pm.top_radius = 0.06
		pm.bottom_radius = 0.06
		pm.height = 2.6
		var pmat := StandardMaterial3D.new()
		pmat.albedo_color = Color(0.8, 0.8, 0.85)
		pm.material = pmat
		pole.mesh = pm
		pole.position = Vector3(0, 1.3, 0)
		add_child(pole)
		var cloth := MeshInstance3D.new()
		var cm := BoxMesh.new()
		cm.size = Vector3(1.1, 0.8, 0.05)
		var cmat := StandardMaterial3D.new()
		cmat.albedo_color = color
		cm.material = cmat
		cloth.mesh = cm
		cloth.position = Vector3(0.6, 2.1, 0)
		add_child(cloth)


func contains(p: Vector3) -> bool:
	var rel := p - global_position
	rel.y = 0.0
	if shape == "circle":
		return rel.length() <= radius
	var along := rel.dot(dir)
	var across := (rel - dir * along).length()
	return absf(along) <= half_len and across <= radius


func _physics_process(delta: float) -> void:
	_t += delta
	if _t >= duration:
		queue_free()
		return
	_tick_t += delta
	if _tick_t >= tick:
		_tick_t -= tick
		_apply()


func _apply() -> void:
	if kind == "damage":
		for e in get_tree().get_nodes_in_group("enemies"):
			var n := e as Node3D
			if n != null and contains(n.global_position):
				n.call("take_damage", amount)
				if slow > 0.0:
					n.call("apply_slow", slow, tick + 0.3)
				if is_instance_valid(player):
					player.call("on_hit_enemy", amount, false)
	elif kind == "heal":
		if is_instance_valid(player) and contains(player.global_position):
			player.call("heal", amount)
