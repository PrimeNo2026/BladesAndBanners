extends Control
## Runder Fähigkeiten-Knopf (Spezial / Super) mit Ladeanzeige. Multitouch-fähig.

signal pressed

var label_text: String = ""
var ratio: float = 1.0
var tint: Color = Color(1, 1, 1)

var _index: int = -1


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func set_ratio(r: float) -> void:
	r = clampf(r, 0.0, 1.0)
	if absf(r - ratio) > 0.004:
		ratio = r
		queue_redraw()


func _input(event: InputEvent) -> void:
	if not is_visible_in_tree():
		return
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed and _index == -1 and get_global_rect().has_point(t.position):
			_index = t.index
			if ratio >= 1.0:
				pressed.emit()
			queue_redraw()
		elif not t.pressed and t.index == _index:
			_index = -1
			queue_redraw()
	elif event is InputEventMouseButton:
		var m := event as InputEventMouseButton
		if m.device != InputEvent.DEVICE_ID_EMULATION and m.pressed and m.button_index == MOUSE_BUTTON_LEFT and get_global_rect().has_point(m.position):
			if ratio >= 1.0:
				pressed.emit()
			get_viewport().set_input_as_handled()


func _draw() -> void:
	var c := size * 0.5
	var r := minf(size.x, size.y) * 0.5 - 4.0
	var is_ready := ratio >= 1.0
	var fill := 0.45 if is_ready else 0.18
	draw_circle(c, r, Color(tint, fill))
	draw_arc(c, r, -PI * 0.5, -PI * 0.5 + TAU * ratio, 48, Color(tint, 0.95), 6.0)
	var font := ThemeDB.fallback_font
	draw_string(font, Vector2(0.0, c.y + 7.0), label_text, HORIZONTAL_ALIGNMENT_CENTER, size.x, 20, Color.WHITE)
