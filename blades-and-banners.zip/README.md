# Blades & Banners – Prototyp 0.2 (Godot 4.6)

Offline-Version: Hauptmenü, Champion-Auswahl (5 Champions), Arena "Burghof von Hohenwacht", Wellenüberleben.

## Steuerung
- Handy: links bewegen, rechts ziehen = zielen, loslassen = schießen (kurz tippen = Auto-Ziel). Knöpfe "Spezial" und "Super" unten rechts.
- PC: WASD bewegen, linke Maustaste schießt, Leertaste Auto-Ziel, Q Spezial, E Super.

## Regeln (Beispielwerte)
- Sieg ab Welle 10: Trophäen und Schmiedesteine, mit jeder weiteren Welle mehr (Limit bei Welle 20).
- Davor Niederlage: Trophäen gehen verloren, unter 100 Trophäen nicht mehr (Anfängerschutz).
- Offline: halbe Belohnung und Tageslimit von 50 Trophäen.
- Meilensteine auf dem Trophäenpfad geben Banner.

## Build
Der Workflow in .github/workflows/build.yml baut die APK und legt sie unter Releases ab.
